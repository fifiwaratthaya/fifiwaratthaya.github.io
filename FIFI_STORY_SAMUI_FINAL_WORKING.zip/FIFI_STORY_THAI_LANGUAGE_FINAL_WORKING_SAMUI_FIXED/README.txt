FIFI STORY — KOH SAMUI

1. Extract this folder completely.
2. Keep the images folder next to the HTML file.
3. Double-click FIFI_STORY_THAI_LANGUAGE_FINAL_WORKING_SAMUI.html to open the website.

Koh Samui album: 8 photos. The 4th photo (palm tree + boats) is the cover, as requested.
